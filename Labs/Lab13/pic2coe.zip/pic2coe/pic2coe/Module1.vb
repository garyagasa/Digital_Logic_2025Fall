﻿Module Module1
    Public redBits As Short = 4
    Public greenBits As Short = 4
    Public blueBits As Short = 4
End Module
