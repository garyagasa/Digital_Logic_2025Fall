﻿Imports System.IO

Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim fName As String = ""
        If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            fName = OpenFileDialog1.FileName
            Me.Text = "图像转.coe格式" & " - " & fName
            PictureBox1.Image = Image.FromFile(fName)

            Dim iWidth, iHeight As Integer
            iHeight = PictureBox1.Image.PhysicalDimension.Height
            iWidth = PictureBox1.Image.PhysicalDimension.Width

            TextBox1.Text = "; .COE file 十六进制数据" & vbCrLf
            TextBox1.Text &= ";Hight: " & iHeight & ", Width: " & iWidth & vbCrLf
            TextBox1.Text &= "memory_initialization_radix=16;" & vbCrLf
            TextBox1.Text &= "memory_initialization_vector=" & vbCrLf

            Dim pic As New Bitmap(fName)
            Dim x, y As Integer
            Dim pixelColor As Color
            Dim r, g, b As Short
            Dim count As Integer

            'StringBuilder可加速字符串的拼接过程
            Dim builder As New System.Text.StringBuilder
            For y = 0 To pic.Height - 1
                count = 0
                For x = 0 To pic.Width - 1
                    count = count + 1

                    '获取(x,y)处像素rgb数据
                    pixelColor = pic.GetPixel(x, y)

                    '原始图像rgb都是8位的，现要转换为4位，右移4位（或除以16）
                    r = pixelColor.R >> (8 - redBits)    '高位补0
                    g = pixelColor.G >> (8 - greenBits)
                    b = pixelColor.B >> (8 - blueBits)

                    '将各为4位的rgb数值拼接在一起，输出一个十进制数据，以16进制显示。
                    If (x = pic.Width - 1) And (y = pic.Height - 1) Then
                        builder.Append(Format(((r << (greenBits + blueBits)) + (g << blueBits) + b), "X") & ";")
                    ElseIf count Mod 10 = 0 Then
                        builder.Append(Format(((r << (greenBits + blueBits)) + (g << blueBits) + b), "X") & "," & vbCrLf)
                    Else
                        builder.Append(Format(((r << (greenBits + blueBits)) + (g << blueBits) + b), "X") & ",")
                    End If
                Next x
            Next y

            TextBox1.Text &= builder.ToString()

            Button3.Enabled = True
        End If


    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        rgb.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Dim coeFileName As String
        Dim fs As FileStream
        Dim w As StreamWriter

        SaveFileDialog1.Filter = "COE文件(*.coe)|*.coe"

        If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            '1) 获取文件名
            coeFileName = SaveFileDialog1.FileName
            '2) 以写方式新建文件
            fs = New FileStream(coeFileName, FileMode.Create, FileAccess.Write)
            '3) 将文本写入fs中
            w = New StreamWriter(fs)
            '4) 将TextBox1文本写到文件中
            w.Write(TextBox1.Text)
            '5) 关闭w和fs
            w.Close()
        End If
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        End
    End Sub
End Class
