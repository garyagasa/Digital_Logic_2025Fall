﻿Public Class rgb

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim r As Short = Val(TextBox1.Text)
        Dim g As Short = Val(TextBox2.Text)
        Dim b As Short = Val(TextBox3.Text)

        If r >= 1 And r <= 8 Then
            redBits = r
        Else
            MsgBox("RED数据输入错误", MsgBoxStyle.OkOnly, "警告")
            TextBox1.Focus()
        End If

        If g >= 1 And g <= 8 Then
            redBits = g
        Else
            MsgBox("GREEN数据输入错误", MsgBoxStyle.OkOnly, "警告")
            TextBox2.Focus()
        End If

        If b >= 1 And b <= 8 Then
            redBits = b
        Else
            MsgBox("BLUE数据输入错误", MsgBoxStyle.OkOnly, "警告")
            TextBox3.Focus()
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class